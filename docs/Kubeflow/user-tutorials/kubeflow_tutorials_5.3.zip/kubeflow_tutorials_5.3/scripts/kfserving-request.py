from lxml import html
import requests
import sys

BASE_URL = sys.argv[1].rstrip("/")
LOGIN = sys.argv[2]
PASSWORD = sys.argv[3]
PROFILE_NAME = sys.argv[4]

HEADERS = {
    "Host": "finance-sample." + PROFILE_NAME + ".example.com",
}

URL = "{}/v1/models/finance-sample:predict".format(BASE_URL)
DATA = {  
  "instances": [[0.7498801,  0.13054666, 0.48037556, 0.861298,   0.38211575, 0.546528,
                 0.92472845, 0.93519026, 0.49693933, 0.94764155, 0.37222895, 0.48792127,
                 0.9342508,  0.43691877, 0.08048747, 0.38780168, 0.7279311,  0.8781489,
                 0.8063569,  0.38024357, 0.5155794,  0.536991,   0.1040775,  0.11094175]]
}

session = requests.Session()
responce = session.post(URL, data=DATA, allow_redirects=False)

if responce.status_code != 200:

    login_with_url = "{}{}".format(BASE_URL, responce.headers['Location'])
    login_with_resp = session.get(login_with_url)
    login_with_html = html.fromstring(login_with_resp.text)

    ldap_auth_link = next(link for (_, _, link, _)
                          in login_with_html.iterlinks()
                          if link.startswith("/dex/auth/ldap"))
    ldap_auth_url = "{}{}".format(BASE_URL, ldap_auth_link)
    answer = session.post(ldap_auth_url, data={"login": LOGIN, "password": PASSWORD}	)

    auth_cookie = session.cookies.get("authservice_session")
    cookies = {'authservice_session': auth_cookie}

    responce = session.post(URL, json=DATA, headers=HEADERS, cookies=cookies)

print(responce.status_code)
print(responce.json())
