import sys
import boto3
import urllib3
from botocore.client import Config
from datetime import datetime
from botocore.exceptions import ClientError


def list_buckets(s3):
    print("\nBuckets:")
    for bucket in s3.list_buckets()['Buckets']:
        print(bucket['Name'])


def create_bucket_if_not_exists(s3, bucket_name):
    print("\nChecking if bucket '" + bucket_name + "' exists")
    try:
        s3.head_bucket(Bucket=bucket_name)
        print("Bucket exists")
    except ClientError:
        print("Bucket does not exist, creating...")
        s3.create_bucket(Bucket=bucket_name)


def list_folder(s3, bucket_name):
    print("\nListing bucket " + bucket_name + ":")
    objects = s3.list_objects(Bucket=bucket_name)
    if 'Contents' in objects:
        for key in objects['Contents']:
            print(key['Key'])
    else:
        print("Is empty")


def delete_all(s3, bucket_name):
    print("\nCleaning all form bucket: " + bucket_name)
    objects = s3.list_objects(Bucket=bucket_name)
    if 'Contents' in objects:
        for key in objects['Contents']:
            s3.delete_object(Bucket=bucket_name, Key=key['Key'])


def upload_file(s3, bucket_name, file_name):
    date = datetime.now().strftime("%m/%d/%Y, %H:%M:%S")
    data = "Hello world on " + date + "!"
    print("\nUploading '" + file_name + "' to '" + bucket_name + "' on " + date)
    s3.put_object(Body=data.encode('ascii'), Bucket=bucket_name, Key=file_name)


def read_file(s3, bucket_name, file_name):
    print("\nReading file '" + file_name + "' from bucket '" + bucket_name + "'")
    obj = s3.get_object(Bucket=bucket_name, Key=file_name)
    print("Data:")
    print(obj['Body'].read().decode('utf-8'))


if __name__ == '__main__':
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    s3 = boto3.client('s3',
                      endpoint_url='https://objectstore-zone1-svc.dataplatform.svc.cluster.local:9000',
                      aws_access_key_id='minioadmin',
                      aws_secret_access_key='minioadmin',
                      config=Config(signature_version='s3v4'),
                      region_name='us-east-1',
                      verify=False)


    bucket = "test"
    file = "test.txt"


    if len(sys.argv) > 1:
        bucket = str(sys.argv[1])


    if len(sys.argv) == 3:
        file = str(sys.argv[2])


    print("Writing file '" + file + "' to bucket '" + bucket + "'")


    list_buckets(s3)
    create_bucket_if_not_exists(s3, bucket)
    list_folder(s3, bucket)
    delete_all(s3, bucket)
    list_folder(s3, bucket)
    upload_file(s3, bucket, file)
    list_folder(s3, bucket)
    read_file(s3, bucket, file)
