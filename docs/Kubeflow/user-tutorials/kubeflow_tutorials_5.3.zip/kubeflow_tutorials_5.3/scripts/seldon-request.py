import json
import requests
import sys


BASE_URL = sys.argv[1].rstrip("/")
LOGIN = sys.argv[2]
PASSWORD = sys.argv[3]
PROFILE_NAME = sys.argv[4]
SDEP_NAME = sys.argv[5]


URL = "{}/seldon/{}/{}/api/v0.1/predictions".format(BASE_URL, PROFILE_NAME, SDEP_NAME)

DATA = {
    "data": {
        "ndarray": [
            [
                """
                issue overview add a new property to disable detection of image
                stream files those ended with -is.yml from target directory.
                expected behaviour by default cube should ld not process image
                stream files if user does not set it. current behaviour cube
                always try to execute -is.yml files which can cause some
                problems in most of cases, for example if you are using
                kubernetes instead of openshift or if you use toget her fabric8
                maven plugin with cube
                """
            ]
        ]
    }
}

data_string = json.dumps(DATA)

session = requests.Session()
responce = session.post(url=URL, data=[("json", data_string)])

if "auth" in responce.url:
    session.post(responce.url, data={"login": LOGIN, "password": PASSWORD})
    responce = session.post(url=URL, data=[("json", data_string)])

print(responce.text)

